import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { Button } from '@mui/material';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';


export default function SystemAdmin({
  //Gets the array of users, the connected user and the option to edit the connected user
  usersArr,currentUser,setCurrentUser
}){
const[rows,setrows]=useState(usersArr);
const[updatedUsers,setupdatedUsers]=useState(rows);
const [chosenUser, setchosenUser] = useState();
const nav = useNavigate()

//Saving the user from the row where the edit button is clicked each time the button is clicked
useEffect(() => {
  setCurrentUser(chosenUser);
  if(chosenUser){
    console.log('chosenUser',chosenUser);
    nav('/edit-profile',{state:{currentUser}});
  } 
 }, [chosenUser])

 //Inserting the array of users into the rows of the table
function insertData(){
    const newRows = JSON.parse(localStorage.getItem('Users')).map(user => ({
        image: user.image,
        username: user.username,
        name: `${user.firstname} ${user.lastname}`,
        dateofbirth: user.dateofbirth,
        address: `${user.street} ${user.housenum},${user.city}`,
        email: user.email,
        user: user,
      }));
      setrows(newRows);
}

//Deleting a user
function deleteUser(index){
    usersArr.splice(index, 1);
    setrows(usersArr);
    setupdatedUsers(rows);
    localStorage.setItem('Users', JSON.stringify(usersArr));    
}

//Updating the rows in the table
useEffect(() => {insertData()}, [updatedUsers])

return(
    <div><br/><br/>   
       <TableContainer component={Paper} dir='rtl'>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell align="right"></TableCell>
            <TableCell align="right">שם משתמש</TableCell>
            <TableCell align="right">שם מלא</TableCell>
            <TableCell align="right">תאריך לידה</TableCell>
            <TableCell align="right">כתובת</TableCell>
            <TableCell align="right">דואר אלקטרוני</TableCell>
            <TableCell align="right"></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row,index) => (
            <TableRow
              key={row.email}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row" key={row.image}>              
                <ImageList sx={{ width: 150, height: 80 }}>
                <ImageListItem>
             <img
                src={row.image}
                alt={row.username}
                loading="lazy"
            />
            </ImageListItem>    
            </ImageList>
              </TableCell>
              <TableCell key={row.username} align="right">{row.username}</TableCell>
              <TableCell key={row.name} align="right">{row.name}</TableCell>
              <TableCell key={row.dateofbirth} align="right">{row.dateofbirth}</TableCell>
              <TableCell key={row.address} align="right">{row.address}</TableCell>
              <TableCell key={row.email} align="right">{row.email}</TableCell>
              <TableCell key={row.user} align="right">
              <Button className='btns' variant="outlined" sx={{color:"red",border:"none"}} startIcon={<DeleteIcon />} onClick={()=>{deleteUser(index)}}></Button>
              <Button className='btns' variant="outlined" sx={{border:"none"}} startIcon={<EditIcon />} onClick={()=>setchosenUser(row.user)}></Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    </div>
)
}