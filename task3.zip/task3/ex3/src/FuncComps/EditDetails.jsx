import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { styled } from '@mui/material/styles';
import { useState, useEffect } from 'react';
import Avatar from '@mui/material/Avatar';
import AutoCompleteCity from './AutoCompleteCity';
import { useNavigate, useParams } from 'react-router';
import { useLocation } from 'react-router-dom';

const VisuallyHiddenInput = styled('input')({
    clip: 'rect(0 0 0 0)',
    clipPath: 'inset(50%)',
    height: 1,
    overflow: 'hidden',
    position: 'absolute',
    bottom: 0,
    left: 0,
    whiteSpace: 'nowrap',
    width: 1,
  });

export default function EditDetails({currentUser, setCurrentUser,setShowEd}){
    const[firstname,setfirstname]=useState(currentUser.firstname);
    const[lastname,setlastname]=useState(currentUser.lastname);
    const[email,setemail]=useState(currentUser.email);
    const[dateofbirth,setdateofbirth]=useState(currentUser.dateofbirth);
    const[city,setcity]=useState(currentUser.city);
    const[street,setstreet]=useState(currentUser.street);
    const[housenum,sethousenum]=useState(currentUser.housenum);
    const[username,setusername]=useState(currentUser.username);
    const[password,setpassword]=useState(currentUser.password);
    const[confirmPassword,setconfirmPassword]=useState(currentUser.confirmPassword);
    const[image,setimage]=useState(currentUser.image);
    const[User,setUser]=useState(currentUser);
    const[imageSrc,setimageSrc]=useState(currentUser.imageSrc);
    const nav = useNavigate();   
    const location = useLocation();

    //Every time the city state is updated it will rerender
    useEffect(() => {}, [city]);

    //Updating the changed values, validation
    function editUser(e){
        e.preventDefault();
        if(!validateForm()){
            return;
        } 
        let user={firstname, lastname,email, dateofbirth,city,street,housenum,username,password,confirmPassword,image,imageSrc};
        setUser(user);
        setCurrentUser(user);
        const users = JSON.parse(localStorage.getItem('Users') ?? "[]")
        const uIndex = users.findIndex(u => u.email === user.email)
        users.splice(uIndex, 1)
        users.push({
            ...user,
        ...user})
        localStorage.setItem('Users', JSON.stringify(users));
        sessionStorage.setItem('LoginUser',JSON.stringify(user));
        alert("User details edited succesfully");

        //return to the page we came from
        if (location.pathname=='/profile') {
            console.log('Navigation is from profile');
            setShowEd(false);
            nav('/profile');
        } else {
            console.log('Navigation is from systemAdmin');
            nav('/systemAdmin');
        }
    }

    function UploadNewImage(e){
        setimageSrc(e.target.value);
        var currentImage=e.target.files[0];        
        const fileReader = new FileReader();    
        fileReader.onload = () => {
            setimage(fileReader.result);
    };
        fileReader.readAsDataURL(currentImage);
    }

    function validateForm() {
        if(!city) {
            alert('Must choose city');
            return ;
        }
        if(!firstname.toString() || Number(firstname)){
            alert('First Name need to be string');
            document.getElementById("firstnameInput").value="";
            firstname=null;
            return false;
        }
        if(!lastname.toString() || Number(lastname)){
            alert('Last Name need to be string');
            document.getElementById("lastnameInput").value="";
            lastname=null;
            return false;
        }
        
        const passwordRegex = /^(?=.*[0-9])(?=.*[A-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,12}/;
        if (!password.match(passwordRegex) || password !== confirmPassword || password.length<7||password.length>12) {
            alert('Invalid password. Please check your details.');
            document.getElementById("passwordInput").value="";
            document.getElementById("password2Input").value="";
            password=null;
            confirmPassword=null;
            return false;
        }

        const usernameRegex = /^[a-zA-Z0-9!@#$%^&*]{1,60}/;
        if (!username.match(usernameRegex)  || username.length>61||username.length<1) {
            alert('Invalid user name. Please check your details.');
            document.getElementById("usernameInput").value="";
            username=null;
            return false;
        }
        const streetRegex = /^[א-ת]/;
        if (!street.match(streetRegex)) {
            alert('Invalid street name. Please check your details.');
            document.getElementById("streetnameInput").value="";
            street=null;
            return false;
        }
        const housenumRegex = /^[0-9]/;
        if (!housenum.match(housenumRegex)) {
            alert('Invalid house number. Please check your details.');
            document.getElementById("housenumInput").value="";
            housenum=null;
            return false;
        }
        const dateofbirthRegex = /^(19[0-9][4-9]|200[1-6])[\-](0?[1-9]|1[012])[\-](0[1-9]|[12][0-9]|3[01])/;
        if (!dateofbirth.match(dateofbirthRegex)) {
            alert('Invalid date of birth. Please check your details.');
            document.getElementById("dateofbirthInput").value="";
            dateofbirth=null;
            return false;
        }
        const imageRegex = /(C:|http(s?):)([\\|/|.|\w|\s|-])*\.(?:jpg|jepg)/;
        if(imageSrc==undefined){
            alert('Upload image file');
            return false;
        }
        if (!imageSrc.match(imageRegex)) {
            alert('Invalid image file. Please check your details.');
            image=null;
            return false;
        }
        return true;
    }

    return(
        <div><br/>
           <h2>EditDetails</h2>
         <form>
            <TextField label="First Name" defaultValue={currentUser.firstname} variant="standard" onChange={(e)=>setfirstname(e.target.value)} /><br/><br/>
            <TextField label="Last Name" defaultValue={currentUser.lastname} variant="standard" onChange={(e)=>setlastname(e.target.value)} /><br/><br/>
            <TextField label="Email" defaultValue={currentUser.email} variant="standard" inputProps={{ readOnly: true}}/><br/><br/>
            <TextField label="Date Of Birth" defaultValue={currentUser.dateofbirth} variant="standard" onChange={(e)=>setdateofbirth(e.target.value)} /><br/><br/>
            <AutoCompleteCity onSelectCity={(c) => setcity(c)}/><br/><br/>
            <TextField label="City" defaultValue={currentUser.city} variant="standard" /><br/><br/>
            <TextField label="Street" defaultValue={currentUser.street} variant="standard" onChange={(e)=>setstreet(e.target.value)} /><br/><br/>
            <TextField label="House Number" defaultValue={currentUser.housenum} variant="standard" onChange={(e)=>sethousenum(e.target.value)} /><br/><br/>
            <TextField label="User Name" defaultValue={currentUser.username} variant="standard" onChange={(e)=>setusername(e.target.value)} /><br/><br/>
            <TextField label="Password" defaultValue={currentUser.password} type='standard' variant="standard" onChange={(e)=>setpassword(e.target.value)} /><br/><br/>
            <TextField label="Confirm Password" defaultValue={currentUser.confirmPassword} type='standard' variant="standard" onChange={(e)=>setconfirmPassword(e.target.value)} /><br/><br/>
            <Avatar sx={{height:150, width:150,marginTop:5,marginLeft:3}} alt="profile image" src={currentUser.image} /><br/><br/>
            <Button
            id='imageInput'
            component="label"
            type='file'
            role={undefined}
            src=''
            variant="contained"
            tabIndex={-1}
            startIcon={<CloudUploadIcon />}
            required
            onChange={(e)=> UploadNewImage(e)}
            >
            Update your Image
            <VisuallyHiddenInput type="file" />
            </Button><br/><br/>
            <Button type='submit' variant="outlined" onClick={editUser}>Update</Button>
            </form>
        </div>
    )
}