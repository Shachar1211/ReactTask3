import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { styled } from '@mui/material/styles';
import { useState } from 'react';
import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import AutoCompleteCity from './AutoCompleteCity';

const VisuallyHiddenInput = styled('input')({
    clip: 'rect(0 0 0 0)',
    clipPath: 'inset(50%)',
    height: 1,
    overflow: 'hidden',
    position: 'absolute',
    bottom: 0,
    left: 0,
    whiteSpace: 'nowrap',
    width: 1,
  });

export default function Register(){
    const nav = useNavigate()
    const[firstname,setfirstname]=useState();
    const[lastname,setlastname]=useState();
    const[email,setemail]=useState();
    const[dateofbirth,setdateofbirth]=useState();
    const[city,setcity]=useState();
    const[street,setstreet]=useState();
    const[housenum,sethousenum]=useState();
    const[username,setusername]=useState();
    const[password,setpassword]=useState();
    const[confirmPassword,setconfirmPassword]=useState();
    const[imageSrc,setimageSrc]=useState();
    const[image,setimage]=useState();
    const [CurrentUsersArr,setCurrentUsersArr] = useState([]);

    //Loading the array of existing users in the system
    const loadUsers = () =>{ 
        setCurrentUsersArr(JSON.parse(localStorage.getItem('Users') ?? '[]'))
    }
    useEffect(() => { loadUsers() }, []) //Any state change will reload the existing users
    
    //Reading the picture
    function uploadImage(e){
        var currentImage=e.target.files[0];
        setimageSrc(e.target.value);
        const fileReader = new FileReader();    
        fileReader.onload = () => {
            setimage(fileReader.result);
            console.log(fileReader.result);
    };
    fileReader.readAsDataURL(currentImage);
}

    //Adding the user to the array of users, validation
    const registerUser=(e)=> {   
        e.preventDefault();
        if(!validateForm()){
            return;
        }           
        let user={firstname, lastname, email, dateofbirth,city,street,housenum,username,password,confirmPassword,image,imageSrc};
        let UsersArr=[...CurrentUsersArr,user];    
        setCurrentUsersArr(user);  
        localStorage.setItem("Users", JSON.stringify(UsersArr));
        alert("Register successfull, you may login")
        nav("/login")
    }
    
    function validateForm() {
        if(!city) {
            alert('Must choose city');
            return ;
        }
        if(!firstname.toString() || Number(firstname)){
            alert('First Name need to be string');
            document.getElementById("firstnameInput").value="";
            firstname=null;
            return false;
        }
        if(!lastname.toString() || Number(lastname)){
            alert('Last Name need to be string');
            document.getElementById("lastnameInput").value="";
            lastname=null;
            return false;
        }
        
        const passwordRegex = /^(?=.*[0-9])(?=.*[A-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,12}/;
        if (!password.match(passwordRegex) || password !== confirmPassword || password.length<7||password.length>12) {
            alert('Invalid password. Please check your details.');
            document.getElementById("passwordInput").value="";
            document.getElementById("password2Input").value="";
            password=null;
            confirmPassword=null;
            return false;
        }

        const usernameRegex = /^[a-zA-Z0-9!@#$%^&*]{1,60}/;
        if (!username.match(usernameRegex)  || username.length>61||username.length<1) {
            alert('Invalid user name. Please check your details.');
            document.getElementById("usernameInput").value="";
            username=null;
            return false;
        }
        const streetRegex = /^[א-ת]/;
        if (!street.match(streetRegex)) {
            alert('Invalid street name. Please check your details.');
            document.getElementById("streetnameInput").value="";
            street=null;
            return false;
        }
        const housenumRegex = /^[0-9]/;
        if (!housenum.match(housenumRegex)) {
            alert('Invalid house number. Please check your details.');
            document.getElementById("housenumInput").value="";
            housenum=null;
            return false;
        }
        const dateofbirthRegex = /^(19[0-9][4-9]|200[1-6])[\-](0?[1-9]|1[012])[\-](0[1-9]|[12][0-9]|3[01])/;
        if (!dateofbirth.match(dateofbirthRegex)) {
            alert('Invalid date of birth. Please check your details.');
            document.getElementById("dateofbirthInput").value="";
            dateofbirth=null;
            return false;
        }
        const emailRegex = /^[\w-\.!#$%^&*]+@([\w-]+\.)+[com]{3}$/;
        if (!email.match(emailRegex)) {
            alert('Invalid email. Please check your details.');
            document.getElementById("emailInput").value="";
            email=null;
            return false;
        }
        const imageRegex = /(C:|http(s?):)([\\|/|.|\w|\s|-])*\.(?:jpg|jepg)/;
        if(imageSrc==undefined){
            alert('Upload image file');
            return false;
        }
        if (!imageSrc.match(imageRegex)) {
            alert('Invalid image file. Please check your details.');
            image=null;
            return false;
        }
        return true;
    }

console.log('retun');
    return(
        <div>
            <h2>Registration form</h2>
         <form>
            <TextField id="firstnameInput" label="First Name" variant="standard" onChange={(e)=>setfirstname(e.target.value)} required/><br/><br/>
            <TextField id="lastnameInput" label="Last Name" variant="standard" onChange={(e)=>setlastname(e.target.value)} required/><br/><br/>
            <TextField id="emailInput" label="Mail Address" type='email' variant="standard" onChange={(e)=>setemail(e.target.value)} required/><br/><br/>
            <TextField id="dateofbirthInput"  type='date' variant="standard" onChange={(e)=>setdateofbirth(e.target.value)} required/><br/><br/>
            <AutoCompleteCity onSelectCity={(c) => setcity(c)}/>
            <TextField id="streetnameInput" label="Street" variant="standard" onChange={(e)=>setstreet(e.target.value)} required/><br/><br/>
            <TextField id="housenumInput" type='number' label="House Number" variant="standard" onChange={(e)=>sethousenum(e.target.value)} required/><br/><br/>
            <TextField id="usernameInput" label="User Name" variant="standard" onChange={(e)=>setusername(e.target.value)} required/><br/><br/>
            <TextField id="passwordInput" label="Password" type='password' variant="standard" onChange={(e)=>setpassword(e.target.value)} required/><br/><br/>
            <TextField id="password2Input" label="confirm Password" type='password' variant="standard" onChange={(e)=>setconfirmPassword(e.target.value)} required/><br/><br/>
            <Button
            id='imageInput'
            component="label"
            type='file'
            role={undefined}
            src=''
            variant="contained"
            tabIndex={-1}
            startIcon={<CloudUploadIcon />}
            required
            onChange={(e)=>uploadImage(e)}
            >
            Upload Image
            <VisuallyHiddenInput type="file" />
            </Button><br/><br/>     
            <Button type='submit' variant="outlined" onClick={registerUser}>Registr</Button>      
            </form>               
        </div>
    )
}